$(function() {

	var predictions = [
		"Праздник",
		"Открытие",
		"Счастье",
		"Удача",
		"Достижение",
		"Гармония",
		"Перемены",
		"Победа",
		"Успех",
		"ЗОЖ",
		"Развлечения",
		"Вдохновение",
		"Приключение",
		"Дружба",
		"Роман",
		"Единение",
		"Любовь",
		"Стабильность",
		"Радость",
		"Добро",
		"Футбол",
		"Рекорд",
		"Прогресс",
		"Позитив",
		"Здоровье",
		"Веселье",
		"Благополучие",
		"Вечеринка",
		"Путешествия",
		"Чудо",
		"Перспективы"
	];

	var clicked = false;

	var random = Math.floor(Math.random() * (predictions.length + 1));
	$('#html_banner .banner_prediction .value').text(predictions[random]);
	$('#html_banner .banner_box_item_cap').css({'backgroundImage' : 'url(./img/pics/' + (random + 1) + '.png)'});

	$('#html_banner .clear').click(function(){
		$('#html_banner .banner').removeClass('clicked');
		$('#html_banner .banner_box_item').removeClass('active');
	});

	$('#html_banner .banner_box_item').click(function(){
		if(!clicked) {
			$(this).addClass('active');
			$(this).parent().parent().addClass('clicked');
			clicked = true;
		}
	});

	$('.share').ShareLink({
		title: 'Я узнал(а), что ждёт меня в 2018 году / новом году. А ты?',
		text: '',
		image: 'http://via.placeholder.com/350x150',
		url: 'https://mail.ru'
	});

});
